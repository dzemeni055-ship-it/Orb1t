(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const STORAGE = { tasks: 'orbit_tasks_v1', goals: 'orbit_goals_v1', notes: 'orbit_notes_v1', theme: 'orbit_theme_v1', sessions: 'orbit_sessions_v1' };
  let tasks = load(STORAGE.tasks, []);
  let filter = 'all';
  let toastTimeout;
  function load(key, fallback) { try { const value = localStorage.getItem(key); return value === null ? fallback : JSON.parse(value); } catch { return fallback; } }
  function save(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { showToast('Не удалось сохранить: возможно, память браузера заполнена.'); return false; } }
  function showToast(message) { const toast = $('#toast'); toast.textContent = message; toast.classList.add('show'); clearTimeout(toastTimeout); toastTimeout = setTimeout(() => toast.classList.remove('show'), 2300); }

  // Theme
  const savedTheme = load(STORAGE.theme, 'dark');
  if (savedTheme === 'light') document.body.classList.add('light');
  $('#themeToggle').textContent = document.body.classList.contains('light') ? '☾' : '☼';
  $('#themeToggle').addEventListener('click', () => {
    document.body.classList.toggle('light');
    const theme = document.body.classList.contains('light') ? 'light' : 'dark';
    save(STORAGE.theme, theme);
    $('#themeToggle').textContent = theme === 'light' ? '☾' : '☼';
  });

  // Date and overview
  const now = new Date();
  $('#todayDate').textContent = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', weekday: 'long' }).format(now);
  $('#year').textContent = now.getFullYear();
  $('#sessionCount').textContent = String(load(STORAGE.sessions, 0));

  // Tasks
  function renderTasks() {
    const list = $('#taskList'); list.replaceChildren();
    const visible = tasks.filter(task => filter === 'all' || (filter === 'open' && !task.done) || (filter === 'done' && task.done));
    visible.forEach(task => {
      const li = document.createElement('li'); li.className = `task-item${task.done ? ' done' : ''}`;
      const check = document.createElement('button'); check.className = 'task-check'; check.type = 'button'; check.textContent = task.done ? '✓' : ''; check.setAttribute('aria-label', task.done ? 'Отметить как активную' : 'Отметить выполненной');
      check.addEventListener('click', () => { task.done = !task.done; save(STORAGE.tasks, tasks); renderTasks(); });
      const text = document.createElement('span'); text.className = 'task-text'; text.textContent = task.text;
      const priority = document.createElement('span'); priority.className = `priority-label${task.priority === 'high' ? ' high' : ''}`; priority.textContent = task.priority === 'high' ? 'Важная' : task.priority === 'low' ? 'Не срочно' : 'Обычная';
      const del = document.createElement('button'); del.className = 'delete-task'; del.type = 'button'; del.textContent = '×'; del.setAttribute('aria-label', 'Удалить задачу');
      del.addEventListener('click', () => { tasks = tasks.filter(item => item.id !== task.id); save(STORAGE.tasks, tasks); renderTasks(); });
      li.append(check, text, priority, del); list.append(li);
    });
    $('#emptyTasks').hidden = visible.length !== 0;
    const done = tasks.filter(t => t.done).length;
    $('#taskProgress').textContent = `${done} из ${tasks.length}`;
    $('#taskProgressText').textContent = tasks.length ? `${Math.round(done / tasks.length * 100)}% завершено` : 'Каждый шаг считается';
    $('#openTasksBadge').textContent = `${tasks.filter(t => !t.done).length} активных`;
  }
  $('#taskForm').addEventListener('submit', event => {
    event.preventDefault();
    const input = $('#taskInput'); const text = input.value.trim();
    if (!text) return;
    tasks.unshift({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, text, priority: $('#taskPriority').value, done: false });
    save(STORAGE.tasks, tasks); input.value = ''; filter = 'all'; $$('.filter').forEach(b => b.classList.toggle('active', b.dataset.filter === filter)); renderTasks(); input.focus();
  });
  $$('.filter').forEach(button => button.addEventListener('click', () => { filter = button.dataset.filter; $$('.filter').forEach(b => b.classList.toggle('active', b === button)); renderTasks(); }));
  $('#clearDone').addEventListener('click', () => { tasks = tasks.filter(t => !t.done); save(STORAGE.tasks, tasks); renderTasks(); showToast('Готовые задачи очищены.'); });
  renderTasks();

  // Three priorities
  const goalIds = ['goal1', 'goal2', 'goal3'];
  const goals = load(STORAGE.goals, ['', '', '']);
  goalIds.forEach((id, i) => { $('#' + id).value = goals[i] || ''; });
  $('#saveGoals').addEventListener('click', () => {
    save(STORAGE.goals, goalIds.map(id => $('#' + id).value.trim()));
    $('#goalSaved').textContent = 'Сохранено ✓'; setTimeout(() => $('#goalSaved').textContent = '', 2200);
  });

  // Focus timer
  let duration = 25 * 60, remaining = duration, interval = null, running = false;
  const display = $('#timerDisplay'), ring = $('#timerRing');
  function drawTimer() {
    const mins = Math.floor(remaining / 60), secs = remaining % 60;
    display.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    const progress = duration ? (duration - remaining) / duration : 0;
    ring.style.background = `conic-gradient(var(--purple) ${progress * 360}deg, rgba(169,149,255,.12) 0deg)`;
    document.title = running ? `${display.textContent} · Orbit` : 'Orbit — твой центр возможностей';
  }
  function stopTimer() { if (interval) clearInterval(interval); interval = null; running = false; $('#timerStart').textContent = '▶ Продолжить'; }
  function completeTimer() {
    stopTimer(); remaining = 0; drawTimer(); $('#timerModeTitle').textContent = 'Отличная работа!'; $('#timerHint').textContent = 'Сделай небольшой перерыв и отметь свой прогресс.'; $('#timerStatus').textContent = 'Сессия завершена';
    const count = load(STORAGE.sessions, 0) + 1; save(STORAGE.sessions, count); $('#sessionCount').textContent = String(count); $('#timerStart').textContent = '↻ Ещё сессия'; showToast('Фокус-сессия завершена. Отличная работа!');
  }
  function startTimer() {
    if (remaining <= 0) { remaining = duration; $('#timerModeTitle').textContent = 'Время сосредоточиться'; $('#timerHint').textContent = 'Убери лишнее и выбери одну задачу.'; }
    if (running) { stopTimer(); $('#timerStatus').textContent = 'На паузе'; drawTimer(); return; }
    running = true; $('#timerStart').textContent = 'Ⅱ Пауза'; $('#timerStatus').textContent = 'Ты в фокусе'; interval = setInterval(() => { if (remaining > 0) remaining--; drawTimer(); if (remaining <= 0) completeTimer(); }, 1000); drawTimer();
  }
  $('#timerStart').addEventListener('click', startTimer);
  $('#timerReset').addEventListener('click', () => { stopTimer(); remaining = duration; $('#timerModeTitle').textContent = 'Время сосредоточиться'; $('#timerHint').textContent = 'Убери лишнее и выбери одну задачу.'; $('#timerStatus').textContent = 'Готов к старту'; $('#timerStart').textContent = '▶ Начать'; drawTimer(); });
  $$('.duration').forEach(button => button.addEventListener('click', () => {
    stopTimer(); duration = Number(button.dataset.minutes) * 60; remaining = duration;
    $$('.duration').forEach(b => b.classList.toggle('active', b === button));
    $('#timerModeTitle').textContent = button.dataset.minutes === '5' ? 'Короткий перерыв или старт' : 'Время сосредоточиться';
    $('#timerHint').textContent = 'Подстрой длительность под задачу и своё самочувствие.';
    $('#timerStatus').textContent = 'Готов к старту'; $('#timerStart').textContent = '▶ Начать'; drawTimer();
  }));
  drawTimer();

  // Search knowledge cards
  $('#knowledgeSearch').addEventListener('input', event => {
    const query = event.target.value.trim().toLocaleLowerCase('ru');
    let shown = 0;
    $$('.knowledge-card').forEach(card => {
      const match = (card.dataset.search + ' ' + card.textContent).toLocaleLowerCase('ru').includes(query);
      card.hidden = !match; if (match) shown++;
    });
    $('#noKnowledge').hidden = shown !== 0;
  });
  // Copy cards without injecting user content into HTML
  $$('.copy-formula').forEach(button => button.addEventListener('click', async () => {
    const text = button.dataset.copy;
    try {
      await navigator.clipboard.writeText(text);
      showToast('Скопировано: ' + text);
    } catch {
      const area = document.createElement('textarea'); area.value = text; area.style.position = 'fixed'; area.style.opacity = '0'; document.body.append(area); area.select();
      const ok = document.execCommand('copy'); area.remove(); showToast(ok ? 'Скопировано!' : 'Не удалось скопировать — выдели формулу вручную.');
    }
  }));

  // Notes
  const notesArea = $('#notesArea');
  notesArea.value = load(STORAGE.notes, '');
  function updateCharCount() { $('#charCount').textContent = `${notesArea.value.length} / 12000`; }
  let noteSaveTimeout;
  notesArea.addEventListener('input', () => {
    updateCharCount(); $('#notesStatus').textContent = 'Сохраняем…'; clearTimeout(noteSaveTimeout);
    noteSaveTimeout = setTimeout(() => { if (save(STORAGE.notes, notesArea.value)) $('#notesStatus').textContent = 'Сохранено локально ✓'; }, 250);
  });
  $('#clearNotes').addEventListener('click', () => {
    if (!notesArea.value || confirm('Очистить заметку? Это действие нельзя отменить.')) {
      notesArea.value = ''; save(STORAGE.notes, ''); updateCharCount(); $('#notesStatus').textContent = 'Заметка очищена';
    }
  });
  updateCharCount();
})();